/*
 * Project name:
     Transmitter (Using mikroE's EasyBee Board)
 * Copyright:
     (c) Mikroelektronika, 2010.
 * Revision History:
     - initial release - 2008.
     - modified by Slavisa Zlatanovic - 11.06.2009.
 * Description:
     This project is a simple demonstration of working with the EasyBee board.
     This example configures EasyBee node to act as a parent in the network which
     sends the data.
* Test configuration:
     MCU:             ds30F4013
                      http://ww1.microchip.com/downloads/en/DeviceDoc/70138F.pdf
     Dev.Board:       EasydsPIC6
                      http://www.mikroe.com/eng/products/view/434/easydspic6-development-system/
     Oscillator:      HS-PLL, 10.000 MHz
     Ext. Modules:    ac:EasyBee_board
     SW:              mikroC PRO for dsPIC
                      http://www.mikroe.com/eng/products/view/231/mikroc-pro-for-dspic30-33-and-pic24/
 * NOTES:
     - EasyBee board on PORTF
     - Module starts sending data after initialisation which can last 10-15 seconds.
     - Initialisation (ZigBit configuration) in this example is repeated every time
       PIC is turned on or reset. This is more convenient for demonstration and
       testing/development, however, it is not necessary as configuration is stored
       in the module and you need to do it only when changing previous configuration.
*/

unsigned short tmp;
char OK_response, state;

void interrupt() iv IVT_ADDR_U2RXINTERRUPT {  // Wait for UART "OK"
  tmp = UART2_Read();                         // get received byte
  U2RXIF_bit = 0;
  switch (state) {
     case 0: {
               if (tmp == 'O')
                  state = 1;
               else
                  state = 0;
               break;
              }

     case 1: {
               if (tmp == 'K')
                 OK_response = 1;
               state = 0;
               break;
              }
  }

}

void wait_ok() {                          // Wait for UART "OK"
  while(OK_response == 0)
    ;
  OK_response = 0;
}

void main() {
  
  state = 0;                              // Init the STATE mashine variables
  OK_response = 0;
  
  ADPCFG = 0xFFFF;                        // Configure AN pins as digital I/O
  NSTDIS_bit = 1;                         // no nesting of interrupts
  U2RXIF_bit = 0;                         // ensure interrupt not pending
  U2RXIE_bit = 1;                         // enable intterupt

  Delay_ms(500);
  UART2_init(38400);                      // Initialize UART2 module
  Delay_ms(3000);
  
  UART2_Write_Text("AT+WAUTONET=0 z");    // Disable automatic networking
  UART2_Write(13);                        // CR
  wait_ok();                              // Wait for UART "OK"

  UART2_Write_Text("ATX");                // Set a node to transmit EVENT and DATA to a host
  UART2_Write(13);                        // CR
  wait_ok();                              // Wait for UART "OK"

  UART2_Write_Text("AT+GSN=1");           // Set MAC address for the node
  UART2_Write(13);                        // CR
  wait_ok();                              // Wait for UART "OK"
  
  UART2_Write_Text("AT+WPANID=1620");      // Set node�s PAN ID
  UART2_Write(13);                        // CR
  wait_ok();                              // Wait for UART "OK"
  
  UART2_Write_Text("AT+WCHMASK=100000");  // Set node�s channel mask
  UART2_Write(13);                        // CR
  wait_ok();                              // Wait for UART "OK"
  
  UART2_Write_Text("AT+WROLE=0 +WSRC=0"); // Switch to coordinator function, set zero address
  UART2_Write(13);                        // CR
  wait_ok();                              // Wait for UART "OK"
  
  UART2_Write_Text("AT+WWAIT=3000");      // Set 3 sec timeout to wait for input
  UART2_Write(13);                        // CR
  wait_ok();                              // Wait for UART "OK"
  
  UART2_Write_Text("AT+WAUTONET=1 z");    // Enable automatic networking(setting 1 sec
                                          // timeout between two consecutive attempts
                                          // to join the network in case of failure) and reboot
  UART2_Write(13);                        // CR
  wait_ok();                              // Wait for UART "OK"

  while (1) {
    LATB++;
    UART2_Write_Text("ATD 55");   // AT command for sending Data
    UART2_Write(13);              // CR
    Delay_ms(500);
    UART2_Write_Text("mikroE");   // Data
    UART2_Write(13);              // CR
    Delay_ms(500);
    UART2_Write_Text("ATD 55");   // AT command for sending Data
    UART2_Write(13);              // CR
    Delay_ms(500);
    UART2_Write_Text("EasyBee");  // Data
    UART2_Write(13);              // CR
    Delay_ms(500);

  }
}