/*
 * Project name:
     Receiver (Using mikroE's EasyBee Board)
 * Copyright:
     (c) Mikroelektronika, 2010.
 * Revision History:
     - initial release - 2008.
     - modified by Slavisa Zlatanovic - 11.06.2009.
  * Description:
     This project is a simple demonstration of working with the EasyBee board.
     This example configures EasyBee node to act as a parent in the network which
     sends the data.
 * Test configuration:
     MCU:             ATmega16
                      http://www.atmel.com/dyn/resources/prod_documents/doc2466.pdf
     Dev.Board:       EasyAVR6
                      http://www.mikroe.com/eng/products/view/321/easyavr6-development-system/
     Oscillator:      HS, 8.000 MHz
     Ext. Modules:    ac:EasyBee_board
     SW:              mikroC PRO for AVR
                      http://www.mikroe.com/eng/products/view/228/mikroc-pro-for-avr/
 * NOTES:
     - Refer to product AT Command manual for more information.
     - Turn off EasyAVR6 development board after loading this aplication into
       the ATmega16
     - Connect the EasyBee on PORTD and turn on the EasyAVR6.
     - After initialisation, data received from transmitter is displayed on LCD.
     - Initialisation (ZigBit configuration) in this example is repeated every time
       AVR is turned on or reset. This is more convenient for demonstration and
       testing/development, however, it is not necessary as configuration is stored
       in the module and you need to do it only when changing previous configuration.
       
*/
// LCD module connections
sbit LCD_RS at PORTD2_bit;
sbit LCD_EN at PORTD3_bit;
sbit LCD_D4 at PORTD4_bit;
sbit LCD_D5 at PORTD5_bit;
sbit LCD_D6 at PORTD6_bit;
sbit LCD_D7 at PORTD7_bit;

sbit LCD_RS_Direction at DDD2_bit;
sbit LCD_EN_Direction at DDD3_bit;
sbit LCD_D4_Direction at DDD4_bit;
sbit LCD_D5_Direction at DDD5_bit;
sbit LCD_D6_Direction at DDD6_bit;
sbit LCD_D7_Direction at DDD7_bit;
// End LCD module connections

char txt[10];
unsigned short i,tmp, tmp2, tmp3, DataReady;
char state, semafor, okstate;

void interrupt() org IVT_ADDR_USART_RXC {
char tmp;
   tmp = UART1_Read();
// We're expecting the sequence of chars "DATA ... : .... CR"
// See the ZigBit module (AT-Commands) manual
// After ":" the receiver module sends to PIC the string of characters which were sent by the transmitter module
    switch (state) {

        case 0: {
                 if (tmp == 'D')
                    state=1;
                 else
                    state=0;
                 break;
                }

        case 1: {
                 if (tmp == 'A')
                    state=2;
                 else
                    state=0;
                 break;
                }

        case 2: {
                if (tmp == 'T')
                   state = 3;
                else
                   state=0;
                break;
                }

        case 3: {
                if (tmp == 'A')
                   state = 4;
                   else
                   state = 0;
                break;
                }

        case 4: {
                if (tmp == ':')
                   state = 5;
                break;
               }

        case 5: {
                 semafor = 1;
                 state = 6;
                 break;
               }

        case 6: {
                if (tmp == 13) {
                    semafor=0;
                    txt[i] = 0;                  // Puting 0 at the end of the string
                    state = 0;
                    DataReady = 1;               // Data is received
                   }
                break;
               }

      default: {
                    state=0;
                    break;
               }
  }//switch

    if (semafor) {
        txt[i] = tmp;                            // Moving the data received from UART to string txt[]
        i++;
    }
  }

void wait() {                                    // Wait for UART "OK"
    tmp2=0;
    while (tmp2==0) {
      tmp3 = UART1_Read();
      switch (okstate) {
         case 0: {
                   if (tmp3 == 'O')
                      okstate = 1;
                   else
                      okstate = 0;
                   break;
                  }

         case 1: {
                   if (tmp3 == 'K'){
                      okstate = 0;
                      tmp2 = 1;
                      }
                   else
                      okstate=1;
                   break;
                  }

        default: {
                      okstate=0;
                      break;
                 }
      }
    }
}

void main() {

  LCD_Init();                                    // LCD Init
  LCD_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);

  Lcd_Out(1,1,"Init...");
  Lcd_Out(2,1,"takes up to 15s");

  Delay_ms(500);
  UART1_init(38400);                             // Initialize UART1 module
  Delay_ms(3000);

  //ZigBit Initialisation

  UART1_Write_Text("AT+WAUTONET=0 z");           // Disable automatic networking
  UART1_Write(13);                               // CR
  wait();                                        // Wait for UART "OK"
    
  UART1_Write_Text("ATX");                       // Set a node to transmit EVENT and DATA to a host
  UART1_Write(13);                               // CR
  wait();                                        // Wait for UART "OK"
    
  UART1_Write_Text("AT+GSN=2");                  // Set MAC address for the node
  UART1_Write(13);                               // CR
  wait();                                        // Wait for UART "OK"
    
  UART1_Write_Text("AT+WPANID=1620");            // Set node�s PAN ID
  UART1_Write(13);                               // CR
  wait();                                        // Wait for UART "OK"
    
  UART1_Write_Text("AT+WCHMASK=100000");         // Set node�s channel mask
  UART1_Write(13);                               // CR
  wait();                                        // Wait for UART "OK"
    
  UART1_Write_Text("AT+WROLE=1 +WSRC=55");       // Switch to coordinator function, set zero address
  UART1_Write(13);                               // CR
  wait();                                        // Wait for UART "OK"
    
  UART1_Write_Text("AT+WAUTONET=1 z");           // Enable automatic networking
                                                 // timeout between two consecutive attempts
                                                 // to join the network in case of failure) and reboot
  UART1_Write(13);                               // CR
  wait();                                        // Wait for UART "OK"

  //End of ZigBit Initialisation
  
  LCD_Cmd(_LCD_CLEAR);

  state = 0;                                     // Init the STATE mashine variables
  semafor = 0;
  DataReady = 0;

  SREG_I_bit  = 1;                               // enable global interrupt
  RXCIE_bit   = 1;                               // enable interrupt on UART receive

  Lcd_Out(1,1,"Init done");
  Delay_ms(1000);

  while (1) {
    tmp = 0;                                     // Init variables
    i = 0;
    memset(txt, 0, 10);                          // Clear array of chars

    SREG_I_bit  = 1;                             // enable global interrupt

    while (!DataReady) {                         // Wait while the data is received
        ;
    }

    DataReady = 0;

    LCD_Cmd(_LCD_CLEAR);                         // Clear display
    Lcd_Cmd(_LCD_FIRST_ROW);
    i = 0;
    while (txt[i] != 0){

       Lcd_Chr_CP(txt[i]);                       // Displaying the received text on the LCD
       i++;                                      // There is delay before the data is displayed
    }                                            // This is due the init duration and synchronization of two Zigbit modules
    
  }
}