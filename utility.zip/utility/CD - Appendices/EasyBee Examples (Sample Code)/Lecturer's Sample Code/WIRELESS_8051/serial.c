#include <T89C51AC2.h>

/*
void serial0() interrupt 4{

    P0=~SBUF;
	RI=0;


}



void main(void)
	{
	
	CKCON=1;
	PCON=0x80;
	TMOD=0x20;//use timer 1,8-bit auto-reload
	TH1=-5; //38400 for normal speed AT 18.432MHZ.
	IEN0=0x90;
	SCON=0x50;
	TR1=1;	  //starti speed.

while(1);
         

	} */

sbit in =P0^0;

void main(void){

unsigned long CNT=0;
in=1;

SCON=0x50; 
T2MOD=0;				  //Timer2
T2CON=0x30;
RCAP2H=0xff	;
RCAP2L=0xf1;


while(CNT<100){

CNT++;
}
TR2=1;


while(1){
	
	if(in==0){
   //////////////////
	  if(TI==1){
	     TI=0;
	           }
	  SBUF='A';
	  while(TI==0);
   ////////////////////

	  //////////////////
	  if(TI==1){
	     TI=0;
	           }
	  SBUF='T';
	  while(TI==0);
   ////////////////////

   //////////////////
	  if(TI==1){
	     TI=0;
	           }
	  SBUF='+';
	  while(TI==0);
   ////////////////////

   //////////////////
	  if(TI==1){
	     TI=0;
	           }
	  SBUF='W';
	  while(TI==0);
   ////////////////////

   //////////////////
	  if(TI==1){
	     TI=0;
	           }
	  SBUF='J';
	  while(TI==0);
   ////////////////////

   //////////////////
	  if(TI==1){
	     TI=0;
	           }
	  SBUF='O';
	  while(TI==0);
   ////////////////////

   //////////////////
	  if(TI==1){
	     TI=0;
	           }
	  SBUF='I';
	  while(TI==0);
   ////////////////////

   //////////////////
	  if(TI==1){
	     TI=0;
	           }
	  SBUF='N';
	  while(TI==0);
   ////////////////////

   //////////////////
	  if(TI==1){
	     TI=0;
	           }
	  SBUF='\n';
	  while(TI==0);
   ////////////////////

	  	   
	  CNT=0;
	  while(CNT<1000){
	  	CNT++;
	                 } 
	}

   else if(in==1){
        RI=0;
	    while((RI==0) && (in==1));
	    
		if(in==1){
		    P1=~SBUF;
	        RI=0;
			}
	   
	   }
		
		}


}