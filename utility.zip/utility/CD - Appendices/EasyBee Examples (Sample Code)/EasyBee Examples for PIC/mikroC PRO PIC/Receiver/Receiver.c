/*
 * Project name:
     Receiver (Using mikroE's EasyBee Board)
 * Copyright:
     (c) Mikroelektronika, 2010.
 * Revision History:
     - initial release - 2008.
     - modified by Slavisa Zlatanovic - 11.06.2009.
     - modified for EasyPIC v7 (16.10.2012. JK)
 * Description:
     This project is a simple demonstration of working with the EasyBee board.
     This example configures one EasyBee node to act as a router which receives
     data and displays it on LCD.
 * Test configuration:
     MCU:             PIC18F45K22
                      http://ww1.microchip.com/downloads/en/DeviceDoc/41412F.pdf
     Dev.Board:       EasyPIC v7
                      http://www.mikroe.com/easypic/
     Oscillator:      HS-PLL, 32.000 MHz
     Ext. Modules:    ac:EasyBee_board
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/mikroc/pic/
 * NOTES:
     - Refer to product AT Command manual for more information.
     - Connect the EasyBee on PORTC and turn on the EasyPIC v7.
     - After initialisation, data received from transmitter is displayed on LCD.
     - Initialisation (ZigBit configuration) in this example is repeated every time
       PIC is turned on or reset. This is more convenient for demonstration and 
       testing/development, however, it is not necessary as configuration is stored
       in the module and you need to do it only when changing previous configuration.
       
*/
sbit LCD_RS at LATB4_bit;
sbit LCD_EN at LATB5_bit;
sbit LCD_D4 at LATB0_bit;
sbit LCD_D5 at LATB1_bit;
sbit LCD_D6 at LATB2_bit;
sbit LCD_D7 at LATB3_bit;

sbit LCD_RS_Direction at TRISB4_bit;
sbit LCD_EN_Direction at TRISB5_bit;
sbit LCD_D4_Direction at TRISB0_bit;
sbit LCD_D5_Direction at TRISB1_bit;
sbit LCD_D6_Direction at TRISB2_bit;
sbit LCD_D7_Direction at TRISB3_bit;
// End LCD module connections

char txt[10];
unsigned short i,tmp, tmp2, tmp3, DataReady;
char state, semafor, okstate, Errorstate;

void interrupt(){                                // Reading the data from UART in the interuppt routine
  if (PIR1.RCIF  == 1){
    tmp = UART1_Read();
// We're expecting the sequence of chars "DATA ... : .... CR"
// See the ZigBit module (AT-Commands) manual
// After ":" the receiver module sends to PIC the string of characters which were sent by the transmitter module
    switch (state) {

        case 0: {
                 if (tmp == 'D')
                    state=1;
                 else
                    state=0;
                 break;
                }

        case 1: {
                 if (tmp == 'A')
                    state=2;
                 else
                    state=0;
                 break;
                }

        case 2: {
                if (tmp == 'T')
                   state = 3;
                else
                   state=0;
                break;
                }

        case 3: {
                if (tmp == 'A')
                   state = 4;
                   else
                   state = 0;
                break;
                }

        case 4: {
                if (tmp == ':')
                   state = 5;
                break;
               }

        case 5: {
                 semafor = 1;
                 state = 6;
                 break;
               }

        case 6: {
                if (tmp == 13) {
                    semafor=0;
                    txt[i] = 0;                  // Puting 0 at the end of the string
                    state = 0;
                    DataReady = 1;               // Data is received
                   }
                break;
               }
        case 10: {
                if (tmp == 'E')
                  state = 11;
                else
                  state = 0;
               }; break;
        case 11: {
                if (tmp == 'R')
                  state = 12;
                else
                  state = 0;
               }; break;
        case 12: {
                if (tmp == 'R')
                  state = 13;
                else
                  state = 0;
               }; break;
        case 13: {
                if (tmp == 'O')
                  state = 14;
                else
                  state = 0;
               }; break;
        case 14: {
                if (tmp == 'R')
                  state = 15;
                else
                  state = 0;
               }; break;
        case 15: {
                if (tmp == 13)
                  Errorstate = 1;
                state = 0;
               }; break;

      default: {
                    state=0;
                    break;
               }
  }//switch

    if (semafor) {
        txt[i] = tmp;                            // Moving the data received from UART to string txt[]
        i++;
    }
   PIR1.RCIF = 0;
  }
}

void wait() {                                 // Wait for UART "OK"
    tmp2=0;
    while ((tmp2 == 0) & (Errorstate == 0)) {
      tmp3 = UART1_Read();
      switch (okstate) {
         case 0: {
                   if (tmp3 == 'O')
                      okstate = 1;
                   else
                      okstate = 0;
                   break;
                  }

         case 1: {
                   if (tmp3 == 'K'){
                      okstate = 0;
                      tmp2 = 1;
                      }
                   else
                      okstate=1;
                   break;
                  }

        default: {
                      okstate=0;
                      break;
                 }
      }
    }
}

void main() {
  ANSELC  = 0;                                 // Configure AN pins as digital I/O
  
  Delay_ms(3000);
  LCD_Init();                                  // LCD Init
  LCD_Cmd(_LCD_CLEAR);
  Lcd_Cmd(_LCD_CURSOR_OFF);

  Lcd_Out(1,1,"Init...");
  Lcd_Out(2,1,"takes up to 15s");

  PIE1.RCIE = 1;                               // Configure interrupts
  PIR1.RCIF = 0;
  INTCON.PEIE = 1;
  INTCON.GIE  = 1;

  Delay_ms(500);
  UART1_init(38400);                           // Initialize UART1 module
  Delay_ms(300);

  //ZigBit Initialisation
  do {
    Errorstate = 0;
    UART1_Write_Text("AT+WAUTONET=0 z");       // Disable automatic networking
    UART1_Write(13);                           // CR
    wait();                                    // Wait for UART "OK"
  } while (Errorstate);
  
  do{
    Errorstate = 0;
    UART1_Write_Text("ATX");                   // Set a node to transmit EVENT and DATA to a host
    UART1_Write(13);                           // CR
    wait();                                    // Wait for UART "OK"
  } while (Errorstate);

  do{
    Errorstate = 0;
    UART1_Write_Text("AT+GSN=2");              // Set MAC address for the node
    UART1_Write(13);                           // CR
    wait();                                    // Wait for UART "OK"
  } while (Errorstate);

  do{
    Errorstate = 0;
    UART1_Write_Text("AT+WPANID=1620");        // Set node�s PAN ID
    UART1_Write(13);                           // CR
    wait();                                    // Wait for UART "OK"
  } while (Errorstate);

  do{
    Errorstate = 0;
    UART1_Write_Text("AT+WCHMASK=100000");     // Set node�s channel mask
    UART1_Write(13);                           // CR
    wait();                                    // Wait for UART "OK"
  } while (Errorstate);

  do{
    Errorstate = 0;
    UART1_Write_Text("AT+WROLE=1 +WSRC=55");   // Switch to coordinator function, set zero address
    UART1_Write(13);                           // CR
    wait();                                    // Wait for UART "OK"
  } while (Errorstate);

  do{
    Errorstate = 0;
    UART1_Write_Text("AT+WAUTONET=1 z");       // Enable automatic networking
                                               // timeout between two consecutive attempts
                                               // to join the network in case of failure) and reboot
    UART1_Write(13);                           // CR
    wait();                                    // Wait for UART "OK"
  } while (Errorstate);
  //End of ZigBit Initialisation
  
  LCD_Cmd(_LCD_CLEAR);

  state = 0;                                   // Init the STATE mashine variables
  semafor = 0;
  DataReady = 0;

  Lcd_Out(1,1,"Init done");
  Delay_ms(1000);

  while (1) {
    tmp = 0;                                   // Init variables
    i = 0;
    memset(txt, 0, 10);                        // Clear array of chars

    INTCON.GIE  = 1;                           // Interrupts allowed

    while (!DataReady) {                       // Wait while the data is received
        ;
    }

    INTCON.GIE  = 0;                           // Interrupts forbiden
    DataReady = 0;

    LCD_Cmd(_LCD_CLEAR);                       // Clear display
    Lcd_Cmd(_LCD_FIRST_ROW);
    i = 0;
    while (txt[i] != 0){

       Lcd_Chr_CP(txt[i]);                     // Displaying the received text on the LCD
       i++;                                    // There is delay before the data is displayed
    }                                          // This is due the init duration and synchronization of two Zigbit modules
    
  }
}