/*
 * Project name:
     Transmitter (Using mikroE's EasyBee Board)
 * Copyright:
     (c) Mikroelektronika, 2010.
 * Revision History:
     - initial release - 2008.
     - modified by Slavisa Zlatanovic - 11.06.2009.
     - modified for EasyPIC v7 (16.10.2012. JK)
 * Description:
     This project is a simple demonstration of working with the EasyBee board.
     This example configures EasyBee node to act as a parent in the network which
     sends the data.
* Test configuration:
     MCU:             PIC18F45K22
                      http://ww1.microchip.com/downloads/en/DeviceDoc/41412F.pdf
     Dev.Board:       EasyPIC v7
                      http://www.mikroe.com/easypic/
     Oscillator:      HS-PLL, 32.000 MHz
     Ext. Modules:    ac:EasyBee_board
     SW:              mikroC PRO for PIC
                      http://www.mikroe.com/mikroc/pic/
 * NOTES:
     - EasyBee board on PORTC
     - Module starts sending data after initialisation which can last 10-15 seconds.
     - Initialisation (ZigBit configuration) in this example is repeated every time
       PIC is turned on or reset. This is more convenient for demonstration and
       testing/development, however, it is not necessary as configuration is stored
       in the module and you need to do it only when changing previous configuration.
*/

unsigned short tmp = 0, tmp2 = 0;
char okstate;

void wait() {                             // Wait for UART "OK"
    while (tmp==0) {
      tmp2 = UART1_Read();
      switch (okstate) {
         case 0: {
                   if (tmp2 == 'O') {
                     okstate = 1;
                   }
                   else
                     okstate = 0;
                   break;
                  }

         case 1: {
                   if (tmp2 == 'K'){
                     okstate = 0;
                     tmp = 1;
                   }
                   else
                     okstate=1;
                   break;
                  }

        default: {
                      okstate=0;
                      break;
                 }
      }
    }
}

void main() {

  ANSELC  = 0;                            // Configure AN pins as digital I/O

  Delay_ms(500);
  UART1_init(38400);                      // Initialize UART1 module
  Delay_ms(300);
  
  UART1_Write_Text("ATX");                // Set a node to transmit EVENT and DATA to a host
  UART1_Write(13);                        // CR
  wait();                                 // Wait for UART "OK"
  
  UART1_Write_Text("AT+GSN=1");           // Set MAC address for the node
  UART1_Write(13);                        // CR
  wait();                                 // Wait for UART "OK"
  
  UART1_Write_Text("AT+WPANID=1620");     // Set node�s PAN ID
  UART1_Write(13);                        // CR
  wait();                                 // Wait for UART "OK"
  
  UART1_Write_Text("AT+WCHMASK=100000");  // Set node�s channel mask
  UART1_Write(13);                        // CR
  wait();                                 // Wait for UART "OK"
  
  UART1_Write_Text("AT+WROLE=0 +WSRC=0"); // Switch to coordinator function, set zero address
  UART1_Write(13);                        // CR
  wait();                                 // Wait for UART "OK"
  
  UART1_Write_Text("AT+WWAIT=3000");      // Set 3 sec timeout to wait for input
  UART1_Write(13);                        // CR
  wait();                                 // Wait for UART "OK"
  
  UART1_Write_Text("AT+WAUTONET=1 z");    // Enable automatic networking(setting 1 sec
                                          // timeout between two consecutive attempts
                                          // to join the network in case of failure) and reboot
  UART1_Write(13);                        // CR
  wait();                                 // Wait for UART "OK"

  while (1) {
    UART1_Write_Text("ATD55");    // AT command for sending Data
    UART1_Write(13);              // CR
    Delay_ms(500);
    UART1_Write_Text("mikroE");   // Data
    UART1_Write(13);              // CR
    Delay_ms(500);
    UART1_Write_Text("ATD55");    // AT command for sending Data
    UART1_Write(13);              // CR
    Delay_ms(500);
    UART1_Write_Text("EasyBee");  // Data
    UART1_Write(13);              // CR
    Delay_ms(500);

  }
}